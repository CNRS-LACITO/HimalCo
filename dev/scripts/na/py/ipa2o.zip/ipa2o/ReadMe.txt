﻿Command line: 
python ipa2o.py <input file>
for instance: 
python ipa2o.py mytext.xml