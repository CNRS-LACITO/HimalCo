var searchData=
[
  ['io_2epy',['io.py',['../io_8py.html',1,'']]],
  ['ipa2sampa_2epy',['ipa2sampa.py',['../ipa2sampa_8py.html',1,'']]]
];
