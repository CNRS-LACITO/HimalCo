var searchData=
[
  ['data',['data',['../namespacepylmflib_1_1pylmflib_1_1utils_1_1ipa2sampa_1_1ipa2sampa.html#a16366cabf343aa667e4b93de905d6d25',1,'pylmflib::pylmflib::utils::ipa2sampa::ipa2sampa']]],
  ['date',['date',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__entry_1_1_lexical_entry.html#a082e7aed55dea8e2d5a8f65a92c2c7d3',1,'pylmflib::pylmflib::core::lexical_entry::LexicalEntry']]],
  ['datecoding',['dateCoding',['../classpylmflib_1_1pylmflib_1_1core_1_1global__information_1_1_global_information.html#ab9f0d76a0d7019f42661a6a54ebe5dc9',1,'pylmflib::pylmflib::core::global_information::GlobalInformation']]],
  ['definition',['definition',['../classpylmflib_1_1pylmflib_1_1core_1_1definition_1_1_definition.html#a60daf69611e01a6f6dd805084185f924',1,'pylmflib.pylmflib.core.definition.Definition.definition()'],['../classpylmflib_1_1pylmflib_1_1core_1_1sense_1_1_sense.html#af7c74e5f49e46fae08a9173745fe46ad',1,'pylmflib.pylmflib.core.sense.Sense.definition()']]],
  ['degree',['degree',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#a99d85c436adbbf07e44d46d44ff9328f',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['degree_5frange',['degree_range',['../namespacepylmflib_1_1pylmflib_1_1common_1_1range.html#ac1168dcdc2d6b856fcc8182c7a0918a7',1,'pylmflib::pylmflib::common::range']]],
  ['derivation',['derivation',['../classpylmflib_1_1pylmflib_1_1core_1_1statement_1_1_statement.html#adfb1de59481ba429a1a404c9f9c48e32',1,'pylmflib::pylmflib::core::statement::Statement']]],
  ['description',['description',['../classpylmflib_1_1pylmflib_1_1core_1_1global__information_1_1_global_information.html#aa17ab419652c4bb942f3c6eadedb81bd',1,'pylmflib.pylmflib.core.global_information.GlobalInformation.description()'],['../classpylmflib_1_1pylmflib_1_1resources_1_1video_1_1_video.html#a471a9ecf7edda3961d0cc2fb4d10758e',1,'pylmflib.pylmflib.resources.video.Video.description()']]],
  ['dialect',['dialect',['../classpylmflib_1_1pylmflib_1_1core_1_1form__representation_1_1_form_representation.html#a92a0a2a636e4edb456f57039edab692e',1,'pylmflib::pylmflib::core::form_representation::FormRepresentation']]],
  ['dtdversion',['dtdVersion',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__resource_1_1_lexical_resource.html#a80eb08733f2c353870bdd10f9d74d5cb',1,'pylmflib::pylmflib::core::lexical_resource::LexicalResource']]],
  ['durationofeffectivespeech',['durationOfEffectiveSpeech',['../classpylmflib_1_1pylmflib_1_1resources_1_1audio_1_1_audio.html#a7a63b1b4e48851dad9a31994592f7c0e',1,'pylmflib::pylmflib::resources::audio::Audio']]]
];
