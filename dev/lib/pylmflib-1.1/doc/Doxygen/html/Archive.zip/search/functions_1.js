var searchData=
[
  ['add_5fdefinition',['add_definition',['../classpylmflib_1_1pylmflib_1_1core_1_1sense_1_1_sense.html#aed53a072f8e36c500e3e63ee42aacc15',1,'pylmflib::pylmflib::core::sense::Sense']]],
  ['add_5fexample',['add_example',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__entry_1_1_lexical_entry.html#a75398d6d4fb6856e06a62360aa5948e9',1,'pylmflib.pylmflib.core.lexical_entry.LexicalEntry.add_example()'],['../classpylmflib_1_1pylmflib_1_1core_1_1sense_1_1_sense.html#a14a1a1fbfd1d3b71e7a1ad61087a9e02',1,'pylmflib.pylmflib.core.sense.Sense.add_example()']]],
  ['add_5fform_5frepresentation',['add_form_representation',['../classpylmflib_1_1pylmflib_1_1morphology_1_1lemma_1_1_lemma.html#a4b70cb04070a18b4e9633c2acdffb552',1,'pylmflib.pylmflib.morphology.lemma.Lemma.add_form_representation()'],['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#a7183f62457ea8ad4e8340d7c2a974dd4',1,'pylmflib.pylmflib.morphology.word_form.WordForm.add_form_representation()']]],
  ['add_5flexical_5fentry',['add_lexical_entry',['../classpylmflib_1_1pylmflib_1_1core_1_1lexicon_1_1_lexicon.html#a673a6c67e54365c48d924753aeead972',1,'pylmflib::pylmflib::core::lexicon::Lexicon']]],
  ['add_5flexicon',['add_lexicon',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__resource_1_1_lexical_resource.html#a3d7979ee24a6c1fc31129126168b7610',1,'pylmflib::pylmflib::core::lexical_resource::LexicalResource']]],
  ['add_5flink',['add_link',['../namespacepylmflib_1_1pylmflib_1_1output_1_1xml__lmf.html#a7c3eb1cee2eb9053976fa98d9a4ffd76',1,'pylmflib::pylmflib::output::xml_lmf']]],
  ['add_5fparadigm',['add_paradigm',['../classpylmflib_1_1pylmflib_1_1core_1_1sense_1_1_sense.html#a18dfc4454875eaedc24425735857cba9',1,'pylmflib::pylmflib::core::sense::Sense']]],
  ['add_5frelated_5fform',['add_related_form',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__entry_1_1_lexical_entry.html#a526ab1df87fe31783eb39336d2e10ddc',1,'pylmflib::pylmflib::core::lexical_entry::LexicalEntry']]],
  ['add_5fsense',['add_sense',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__entry_1_1_lexical_entry.html#a657f09eb98b1cc9dba66d8864476fe53',1,'pylmflib::pylmflib::core::lexical_entry::LexicalEntry']]],
  ['add_5fstatement',['add_statement',['../classpylmflib_1_1pylmflib_1_1core_1_1definition_1_1_definition.html#ab0f3104c631e07b09a05e77af14736ae',1,'pylmflib::pylmflib::core::definition::Definition']]],
  ['add_5ftext_5frepresentation',['add_text_representation',['../classpylmflib_1_1pylmflib_1_1mrd_1_1context_1_1_context.html#a6a44eadd0dacbe3d2f264913e45f7528',1,'pylmflib::pylmflib::mrd::context::Context']]],
  ['add_5fword_5fform',['add_word_form',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__entry_1_1_lexical_entry.html#a345c74a6d045ccfbd7d3e7e2f2955467',1,'pylmflib::pylmflib::core::lexical_entry::LexicalEntry']]]
];
