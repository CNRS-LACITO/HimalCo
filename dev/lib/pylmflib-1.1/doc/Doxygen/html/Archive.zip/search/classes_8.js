var searchData=
[
  ['lemma',['Lemma',['../classpylmflib_1_1pylmflib_1_1morphology_1_1lemma_1_1_lemma.html',1,'pylmflib::pylmflib::morphology::lemma']]],
  ['lexicalentry',['LexicalEntry',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__entry_1_1_lexical_entry.html',1,'pylmflib::pylmflib::core::lexical_entry']]],
  ['lexicalresource',['LexicalResource',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__resource_1_1_lexical_resource.html',1,'pylmflib::pylmflib::core::lexical_resource']]],
  ['lexicon',['Lexicon',['../classpylmflib_1_1pylmflib_1_1core_1_1lexicon_1_1_lexicon.html',1,'pylmflib::pylmflib::core::lexicon']]],
  ['listofcomponents',['ListOfComponents',['../classpylmflib_1_1pylmflib_1_1morphology_1_1list__of__components_1_1_list_of_components.html',1,'pylmflib::pylmflib::morphology::list_of_components']]]
];
