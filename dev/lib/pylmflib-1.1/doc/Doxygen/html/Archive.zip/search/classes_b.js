var searchData=
[
  ['paradigm',['Paradigm',['../classpylmflib_1_1pylmflib_1_1morphosyntax_1_1paradigm_1_1_paradigm.html',1,'pylmflib::pylmflib::morphosyntax::paradigm']]],
  ['picture',['Picture',['../classpylmflib_1_1pylmflib_1_1resources_1_1picture_1_1_picture.html',1,'pylmflib::pylmflib::resources::picture']]]
];
