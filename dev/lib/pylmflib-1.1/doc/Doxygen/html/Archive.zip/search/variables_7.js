var searchData=
[
  ['ge',['ge',['../namespacepylmflib_1_1pylmflib_1_1utils_1_1tables_1_1tables.html#ace116ea26d3917bc44c0f96068c02d52',1,'pylmflib::pylmflib::utils::tables::tables']]],
  ['geographicalvariant',['geographicalVariant',['../classpylmflib_1_1pylmflib_1_1core_1_1form__representation_1_1_form_representation.html#a6c161684be9db019b8e5d1158dbf6090',1,'pylmflib::pylmflib::core::form_representation::FormRepresentation']]],
  ['gf',['gf',['../namespacepylmflib_1_1pylmflib_1_1utils_1_1tables_1_1tables.html#abcf8610aba2e8f2f706e540f0094ef75',1,'pylmflib::pylmflib::utils::tables::tables']]],
  ['global_5finformation',['global_information',['../classpylmflib_1_1pylmflib_1_1core_1_1lexical__resource_1_1_lexical_resource.html#ad460a75f97721397f0771bc65a6312e7',1,'pylmflib::pylmflib::core::lexical_resource::LexicalResource']]],
  ['gloss',['gloss',['../classpylmflib_1_1pylmflib_1_1core_1_1definition_1_1_definition.html#a58d6765d4fde7e3f7e50c2de65f5296c',1,'pylmflib::pylmflib::core::definition::Definition']]],
  ['gn',['gn',['../namespacepylmflib_1_1pylmflib_1_1utils_1_1tables_1_1tables.html#a2e9b3c34b41733a5bd18371e671a99fd',1,'pylmflib::pylmflib::utils::tables::tables']]],
  ['grammaticalgender',['grammaticalGender',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#ab0fa51aa2784e2b35c32094d69b16a90',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['grammaticalgender_5frange',['grammaticalGender_range',['../namespacepylmflib_1_1pylmflib_1_1common_1_1range.html#aec15222fb77df51278a4c627312ef429',1,'pylmflib::pylmflib::common::range']]],
  ['grammaticalnumber',['grammaticalNumber',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#a249d7afba23dc9ea69902841fca4bf6c',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['grammaticalnumber_5frange',['grammaticalNumber_range',['../namespacepylmflib_1_1pylmflib_1_1common_1_1range.html#ac667a36e7356c2232212e7d9a344c0cc',1,'pylmflib::pylmflib::common::range']]]
];
