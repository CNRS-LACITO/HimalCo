var searchData=
[
  ['global_5finformation_2epy',['global_information.py',['../global__information_8py.html',1,'']]]
];
