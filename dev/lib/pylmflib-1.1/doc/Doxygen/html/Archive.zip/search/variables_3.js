var searchData=
[
  ['case',['case',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#aedf875bb2d18b90111443431d1c4e8b8',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['characterencoding',['characterEncoding',['../classpylmflib_1_1pylmflib_1_1core_1_1global__information_1_1_global_information.html#ac6adb1171ecc9bf9a55b497748d3a313',1,'pylmflib::pylmflib::core::global_information::GlobalInformation']]],
  ['citationform',['citationForm',['../classpylmflib_1_1pylmflib_1_1core_1_1form__representation_1_1_form_representation.html#a3179e40656d80243d62a2e1b843b446e',1,'pylmflib::pylmflib::core::form_representation::FormRepresentation']]],
  ['clusivity',['clusivity',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#a99b4340020891c8caebf3f9fc2471c19',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['clusivity_5frange',['clusivity_range',['../namespacepylmflib_1_1pylmflib_1_1common_1_1range.html#a3536a899a3577d0be958152e4b613d4b',1,'pylmflib::pylmflib::common::range']]],
  ['comment',['comment',['../classpylmflib_1_1pylmflib_1_1core_1_1form__representation_1_1_form_representation.html#ae75e2f1914708387ebfabe644867f25c',1,'pylmflib.pylmflib.core.form_representation.FormRepresentation.comment()'],['../classpylmflib_1_1pylmflib_1_1core_1_1representation_1_1_representation.html#abb435aa030be326b94c1b8610af5c1d7',1,'pylmflib.pylmflib.core.representation.Representation.comment()'],['../classpylmflib_1_1pylmflib_1_1core_1_1text__representation_1_1_text_representation.html#a67af916a2aaef7151f2db539c41ae2c6',1,'pylmflib.pylmflib.core.text_representation.TextRepresentation.comment()']]],
  ['component',['component',['../classpylmflib_1_1pylmflib_1_1morphology_1_1list__of__components_1_1_list_of_components.html#aa16c07d7e862bf8adf0ac5d38b2d27bc',1,'pylmflib::pylmflib::morphology::list_of_components::ListOfComponents']]],
  ['context',['context',['../classpylmflib_1_1pylmflib_1_1core_1_1sense_1_1_sense.html#a5498340a708c408d71451b9504e86bd8',1,'pylmflib::pylmflib::core::sense::Sense']]],
  ['contextualvariation',['contextualVariation',['../classpylmflib_1_1pylmflib_1_1core_1_1form__representation_1_1_form_representation.html#a57d26544565e4428881e4029ff5a0202',1,'pylmflib::pylmflib::core::form_representation::FormRepresentation']]],
  ['creationdate',['creationDate',['../classpylmflib_1_1pylmflib_1_1core_1_1global__information_1_1_global_information.html#a4a773cca476735bdd3a4f38ab1f43e7c',1,'pylmflib::pylmflib::core::global_information::GlobalInformation']]]
];
