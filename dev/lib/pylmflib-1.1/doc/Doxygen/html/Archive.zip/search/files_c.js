var searchData=
[
  ['paradigm_2epy',['paradigm.py',['../paradigm_8py.html',1,'']]],
  ['picture_2epy',['picture.py',['../picture_8py.html',1,'']]]
];
