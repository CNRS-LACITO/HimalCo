var searchData=
[
  ['variantform',['variantForm',['../classpylmflib_1_1pylmflib_1_1core_1_1form__representation_1_1_form_representation.html#af54eac5b21b7ff42519edce35e124015',1,'pylmflib::pylmflib::core::form_representation::FormRepresentation']]],
  ['verbformmood',['verbFormMood',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#ab9e07afe9b52a3888fa597ee96162fc8',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['verbformmood_5frange',['verbFormMood_range',['../namespacepylmflib_1_1pylmflib_1_1common_1_1range.html#a05acf1f56d36cf0977164462c7607710',1,'pylmflib::pylmflib::common::range']]],
  ['vernacular',['VERNACULAR',['../namespacepylmflib_1_1pylmflib_1_1common_1_1defs.html#ae65c3fc4da5c02e0a0e131d9e3328e12',1,'pylmflib::pylmflib::common::defs']]],
  ['version',['version',['../classpylmflib_1_1pylmflib_1_1core_1_1global__information_1_1_global_information.html#a41713aa047a9d2827506e884fa565aa9',1,'pylmflib::pylmflib::core::global_information::GlobalInformation']]],
  ['video',['Video',['../classpylmflib_1_1pylmflib_1_1resources_1_1video_1_1_video.html',1,'pylmflib::pylmflib::resources::video']]],
  ['video_2epy',['video.py',['../video_8py.html',1,'']]],
  ['voice',['voice',['../classpylmflib_1_1pylmflib_1_1morphology_1_1word__form_1_1_word_form.html#a3f85ffcb5751631f3097bd43ee43c57e',1,'pylmflib::pylmflib::morphology::word_form::WordForm']]],
  ['voice_5frange',['voice_range',['../namespacepylmflib_1_1pylmflib_1_1common_1_1range.html#ad1b9d809d91fdd5091e65aadf589c123',1,'pylmflib::pylmflib::common::range']]],
  ['vowelharmony',['vowelHarmony',['../classpylmflib_1_1pylmflib_1_1core_1_1lexicon_1_1_lexicon.html#a6840b360b79472e3b15efb0d15daa3a1',1,'pylmflib::pylmflib::core::lexicon::Lexicon']]]
];
