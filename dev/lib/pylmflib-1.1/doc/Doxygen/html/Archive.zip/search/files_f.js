var searchData=
[
  ['tables_2epy',['tables.py',['../tables_8py.html',1,'']]],
  ['tex_2epy',['tex.py',['../output_2tex_8py.html',1,'']]],
  ['tex_2epy',['tex.py',['../config_2tex_8py.html',1,'']]],
  ['text_5frepresentation_2epy',['text_representation.py',['../text__representation_8py.html',1,'']]]
];
