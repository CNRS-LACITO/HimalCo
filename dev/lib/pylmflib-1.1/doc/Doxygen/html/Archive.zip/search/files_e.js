var searchData=
[
  ['sense_2epy',['sense.py',['../sense_8py.html',1,'']]],
  ['speaker_2epy',['speaker.py',['../speaker_8py.html',1,'']]],
  ['statement_2epy',['statement.py',['../statement_8py.html',1,'']]],
  ['stem_2epy',['stem.py',['../stem_8py.html',1,'']]],
  ['subject_5ffield_2epy',['subject_field.py',['../subject__field_8py.html',1,'']]]
];
